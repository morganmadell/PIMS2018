%%

T = readtable('data.csv', 'Delimiter', ',');
%T.X_TD_TVD{i} = str2num(T.X_TD_TVD{i});

%%
    
[names, ~, loc] = unique(T.X_UWI_DISPLAY);

%%



q1 = T(1:113,15);

q1 = table2array(q1);
y1 = log(q1);
t = (1:113)';
N = length(t); 
plot(t,y1,'o')

%%
%Just a try //= =\\
% M = 100;
% for r = 1:M
%     for T = 1:N 
%             a(T,r) = rand(1);
%             if a (T,r)>0.5
%                 x(T,r) = 1;
%             else
%                 x(T,r) = -1;
%             end
%             B(T,r) = sum(x(1:T,r));
%     end
% end
%%
NP = 7;
myfun = @(params) intmodel(q1,t,params);
gaopts = gaoptimset('display','none','useparallel',false,...
    'plotfcns',@gaplotbestf,'generations',3000*NP,'populationsize',100,...
    'tolfun',1e-10);
% options = optimoptions('ga','ConstraintTolerance',1e-6,'PlotFcn', @gaplotbestf);
A = []; b = []; Aeq = []; beq = [];
LB = [0,0,0,-inf,0,-inf,0]; UB = [inf,inf,1,inf,inf,inf,1]; % lower and upper bounds for the variables
[params,LL] = ga(myfun,NP,A,b,Aeq,beq,LB,UB,[],gaopts);

%%
D_inf = params(1);
D = params(2);
n = params(3);
e = params(4);
m_0 = params(5);
lambda = params(6);
m = params(7);


alpha = [];
hold off
plot(t,y1,'o')
hold on

for i = 1:10
    alpha(i)=randn;
end

BM = bm(0,1);
path = simByEuler(BM, N-1);

for j = 1:10
BM = bm(0,1);
path = simByEuler(BM, N-1); 
% start = min(t);
% final = max(t);
% g =@(t) lambda*path(t)./(1+t);
for i = 1:N
    r(i)=randn;
end
k =@(t) lambda/(1+(t).^m);
for c = 1:N
K(c) = k(c).*r(c);
KK(j,c) = K(c);
S(j,c) = sum(KK(j,1:c));
end
syms x
f =@(x) m_0+e*alpha(j)-D_inf*x-D*x.^n+S(j,x);
% lambda*path(x)./(1+x);
ind = 1:N;
F(j,ind) = f(ind);
% K(j,t) = exp(F(j,t));
plot(t,F(j,ind));
hold on
end

G(t) = mean(F(:,t));
plot(t,G(t),'o')




