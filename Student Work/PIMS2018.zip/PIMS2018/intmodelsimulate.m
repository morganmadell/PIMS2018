T = readtable('data.csv', 'Delimiter', ',');
q1 = T(1:113,15);
q1 = table2array(q1);
y1 = log(q1);
t = (1:113)';
N = length(t); 
plot(t,y1,'o')

q0 = q1(1:95);
tt = t(1:95);
NP = 6;
myfun = @(params) intmodel(q0,tt,params);
gaopts = gaoptimset('display','none','useparallel',false,...
    'plotfcns',@gaplotbestf,'generations',3000*NP,'populationsize',100,...
    'tolfun',1e-10);
% options = optimoptions('ga','ConstraintTolerance',1e-6,'PlotFcn', @gaplotbestf);
A = []; b = []; Aeq = []; beq = [];
LB = [0,0,0,0,-inf,0]; UB = [inf,inf,1,inf,inf,1]; % lower and upper bounds for the variables
[params,LL] = ga(myfun,NP,A,b,Aeq,beq,LB,UB,[],gaopts);

%%
D_inf = params(1);
D = params(2);
n = params(3);
% e = params(4);
m_0 = params(4);
lambda = params(5);
m = params(6);

alpha = [];
hold off
plot(t,y1,'o')
hold on

for i = 1:20
    alpha(i)=randn;
end

% BM = bm(0,1);
% path = simByEuler(BM, N-1);

for j = 1:20
BM = bm(0,1);
path = simByEuler(BM, N-1); 
% start = min(t);
% final = max(t);
% g =@(t) lambda*path(t)./(1+t);
for i = 95:N
    r(i)=randn;
end
k =@(t) lambda/(1+(t).^m);
for c = 95:N
K(c) = k(c).*r(c);
KK(j,c) = K(c);
S(j,c) = sum(KK(j,95:c));
end
syms x
f =@(x) log(q1(95))-D_inf*(x-95)-D*((x).^n-95^n)+S(j,x);%lambda*path(t)./(1+t)
ind = 95:N;
F(j,ind) = f(ind);
% K(j,t) = exp(F(j,t));
plot(t(95:N),F(j,ind));
hold on
end
for z = 95:N
G(z) = mean(F(:,z));
end
plot(t(95:N),G(95:N),'sr')
hold on